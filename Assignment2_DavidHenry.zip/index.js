import express from "express";
import path from "path";
import "dotenv/config";

import appFunctions from "./components/api.js";

const __dirname = import.meta.dirname;

//express app
const app = express();
const port = process.env.port;

//define folders
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");

app.use(express.static(path.join(__dirname, "public")));

//page routes
app.get("/", async (req, res) =>
{
    let colorList = await appFunctions.getColours();

    res.render("index", {colors: colorList});
});

//setup server listening
app.listen(port, () => 
{
    console.log(`listening on http://localhost:${port}`);
});